import { useEffect } from "react";
import Prism from "prismjs";
import "prismjs/components/prism-markup";
import "prismjs/components/prism-css";
import "prismjs/components/prism-javascript";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";

interface CodeViewerProps {
  code: string;
  language?: string;
}

export default function CodeViewer({ code, language = "html" }: CodeViewerProps) {
  useEffect(() => {
    Prism.highlightAll();
  }, [code, language]);

  return (
    <Card className="relative w-full overflow-hidden bg-zinc-950 border-zinc-800 font-mono text-sm shadow-2xl">
      <div className="flex items-center justify-between px-4 py-2 bg-zinc-900 border-b border-zinc-800">
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50" />
          <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50" />
          <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50" />
        </div>
        <div className="text-xs text-zinc-500 font-medium">view-source:result</div>
        <div className="w-10" /> {/* Spacer for balance */}
      </div>
      
      <ScrollArea className="h-[600px] w-full">
        <div className="p-4 min-w-max">
          <pre className="!bg-transparent !m-0 !p-0">
            <code className={`language-${language}`}>
              {code}
            </code>
          </pre>
        </div>
        <ScrollBar orientation="horizontal" />
        <ScrollBar orientation="vertical" />
      </ScrollArea>
    </Card>
  );
}
