import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Search, Code2, AlertCircle, Loader2, Globe, Copy, Check, FileCode, FileText, Braces, Download, FolderTree } from "lucide-react";
import CodeViewer from "@/components/code-viewer";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { motion, AnimatePresence } from "framer-motion";

interface ExtractedResource {
  type: "html" | "css" | "javascript" | "inline-css" | "inline-js";
  url?: string;
  content: string;
  filename?: string;
}

interface ExtractionResult {
  url: string;
  title: string;
  resources: ExtractedResource[];
  error?: string;
}

export default function Home() {
  const [url, setUrl] = useState("");
  const [result, setResult] = useState<ExtractionResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<ExtractedResource | null>(null);
  const { toast } = useToast();

  const handleInspect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;

    setLoading(true);
    setError(null);
    setResult(null);
    setSelectedFile(null);

    try {
      const response = await fetch("/api/extract", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to fetch source code");
      }

      setResult(data);
      if (data.resources && data.resources.length > 0) {
        setSelectedFile(data.resources[0]);
      }
      toast({
        title: "সাফল্য!",
        description: `${data.resources.length}টি ফাইল এক্সট্র্যাক্ট করা হয়েছে।`,
      });
    } catch (err: any) {
      setError(err.message || "ওয়েবসাইট থেকে কোড নিতে ব্যর্থ হয়েছে।");
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not retrieve source code.",
      });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (content: string, filename: string) => {
    navigator.clipboard.writeText(content);
    setCopied(filename);
    setTimeout(() => setCopied(null), 2000);
    toast({
      title: "কপি হয়েছে",
      description: `${filename} ক্লিপবোর্ডে কপি করা হয়েছে`,
    });
  };

  const downloadFile = (content: string, filename: string) => {
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    toast({
      title: "ডাউনলোড শুরু",
      description: `${filename} ডাউনলোড হচ্ছে`,
    });
  };

  const downloadAll = () => {
    if (!result) return;
    result.resources.forEach((res, i) => {
      setTimeout(() => {
        downloadFile(res.content, res.filename || `file-${i}`);
      }, i * 200);
    });
  };

  const getLanguage = (type: string) => {
    switch (type) {
      case "html": return "html";
      case "css":
      case "inline-css": return "css";
      case "javascript":
      case "inline-js": return "javascript";
      default: return "html";
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case "html": return <FileText className="w-4 h-4" />;
      case "css":
      case "inline-css": return <FileCode className="w-4 h-4 text-blue-400" />;
      case "javascript":
      case "inline-js": return <Braces className="w-4 h-4 text-yellow-400" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const groupedResources = result?.resources.reduce((acc, res) => {
    const group = res.type.includes("css") ? "CSS" : res.type.includes("js") ? "JavaScript" : "HTML";
    if (!acc[group]) acc[group] = [];
    acc[group].push(res);
    return acc;
  }, {} as Record<string, ExtractedResource[]>);

  return (
    <div className="min-h-screen w-full bg-background text-foreground selection:bg-primary/20 selection:text-primary">
      <div className="fixed inset-0 z-0 pointer-events-none opacity-[0.03]" 
           style={{ 
             backgroundImage: "linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)", 
             backgroundSize: "40px 40px" 
           }} 
      />
      
      <div className="relative z-10 container max-w-7xl mx-auto px-4 py-8 md:py-12 flex flex-col items-center gap-6">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center space-y-3"
        >
          <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-primary/10 text-primary mb-2">
            <Code2 className="w-8 h-8" />
          </div>
          <h1 className="text-3xl md:text-5xl font-black tracking-tight font-sans">
            Source <span className="text-primary">Inspector</span>
          </h1>
          <p className="text-muted-foreground text-base max-w-xl mx-auto">
            যে কোনো ওয়েবসাইটের সম্পূর্ণ সোর্স কোড (HTML, CSS, JS) এক্সট্র্যাক্ট করুন
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="w-full max-w-2xl"
        >
          <Card className="p-2 bg-card/50 backdrop-blur-sm border-zinc-800 shadow-xl">
            <form onSubmit={handleInspect} className="flex flex-col sm:flex-row gap-2" data-testid="form-extract">
              <div className="relative flex-1">
                <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="https://example.com" 
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="pl-10 h-12 bg-zinc-950/50 border-zinc-800 focus-visible:ring-primary font-mono"
                  data-testid="input-url"
                />
              </div>
              <Button 
                type="submit" 
                disabled={loading || !url}
                className="h-12 px-8 font-semibold transition-all hover:scale-105 active:scale-95"
                data-testid="button-extract"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Extracting...
                  </>
                ) : (
                  <>
                    <Search className="mr-2 h-4 w-4" />
                    Extract
                  </>
                )}
              </Button>
            </form>
          </Card>
        </motion.div>

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="w-full max-w-2xl"
            >
              <Alert variant="destructive" className="bg-red-950/20 border-red-900/50 text-red-200">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Connection Failed</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {result && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
              className="w-full space-y-4"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 w-full">
                <div>
                  <h3 className="text-xl font-bold flex items-center gap-2">
                    <span className="w-2 h-6 bg-primary rounded-full"/>
                    {result.title}
                  </h3>
                  <p className="text-sm text-muted-foreground font-mono">{result.url}</p>
                </div>
                <div className="flex gap-2">
                  <Badge variant="secondary" className="gap-1">
                    <FolderTree className="w-3 h-3" />
                    {result.resources.length} ফাইল
                  </Badge>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={downloadAll}
                    className="border-zinc-800 hover:bg-zinc-800 text-zinc-400 hover:text-white"
                    data-testid="button-download-all"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    সব ডাউনলোড
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                {/* File Tree */}
                <Card className="lg:col-span-1 bg-zinc-900/50 border-zinc-800 p-4 max-h-[600px] overflow-auto">
                  <h4 className="font-semibold text-sm text-zinc-400 mb-3 flex items-center gap-2">
                    <FolderTree className="w-4 h-4" />
                    ফাইল স্ট্রাকচার
                  </h4>
                  
                  <Tabs defaultValue="HTML" className="w-full">
                    <TabsList className="w-full grid grid-cols-3 bg-zinc-800/50 mb-3">
                      <TabsTrigger value="HTML" className="text-xs">HTML</TabsTrigger>
                      <TabsTrigger value="CSS" className="text-xs">CSS</TabsTrigger>
                      <TabsTrigger value="JavaScript" className="text-xs">JS</TabsTrigger>
                    </TabsList>
                    
                    {groupedResources && Object.entries(groupedResources).map(([group, files]) => (
                      <TabsContent key={group} value={group} className="space-y-1 mt-0">
                        {files.map((file, i) => (
                          <button
                            key={i}
                            onClick={() => setSelectedFile(file)}
                            className={`w-full text-left p-2 rounded-lg text-sm flex items-center gap-2 transition-colors ${
                              selectedFile === file 
                                ? "bg-primary/20 text-primary" 
                                : "hover:bg-zinc-800 text-zinc-300"
                            }`}
                            data-testid={`file-item-${i}`}
                          >
                            {getIcon(file.type)}
                            <span className="truncate flex-1 font-mono text-xs">
                              {file.filename}
                            </span>
                            <Badge variant="outline" className="text-[10px] shrink-0">
                              {file.type.includes("inline") ? "inline" : "ext"}
                            </Badge>
                          </button>
                        ))}
                      </TabsContent>
                    ))}
                  </Tabs>
                </Card>

                {/* Code Viewer */}
                <div className="lg:col-span-3">
                  {selectedFile && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {getIcon(selectedFile.type)}
                          <span className="font-mono text-sm text-zinc-300">{selectedFile.filename}</span>
                          {selectedFile.url && (
                            <span className="text-xs text-zinc-500 truncate max-w-md">
                              ({selectedFile.url})
                            </span>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => copyToClipboard(selectedFile.content, selectedFile.filename || 'file')}
                            className="text-zinc-400 hover:text-white"
                            data-testid="button-copy-file"
                          >
                            {copied === selectedFile.filename ? (
                              <Check className="w-4 h-4" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => downloadFile(selectedFile.content, selectedFile.filename || 'file')}
                            className="text-zinc-400 hover:text-white"
                            data-testid="button-download-file"
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <CodeViewer 
                        code={selectedFile.content} 
                        language={getLanguage(selectedFile.type)} 
                      />
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {!result && !loading && !error && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl mt-4 text-zinc-400"
          >
            {[
              { title: "সম্পূর্ণ এক্সট্র্যাকশন", desc: "HTML, CSS, এবং JavaScript ফাইল একসাথে এক্সট্র্যাক্ট করুন।" },
              { title: "সিনট্যাক্স হাইলাইট", desc: "রঙিন কোড ভিউ যাতে পড়তে সুবিধা হয়।" },
              { title: "এক ক্লিকে ডাউনলোড", desc: "সব ফাইল একসাথে বা আলাদাভাবে ডাউনলোড করুন।" }
            ].map((feature, i) => (
              <div key={i} className="p-6 rounded-2xl bg-zinc-900/30 border border-zinc-800/50 backdrop-blur-sm text-center hover:bg-zinc-900/50 transition-colors">
                <h3 className="font-semibold text-zinc-200 mb-2">{feature.title}</h3>
                <p className="text-sm text-zinc-500">{feature.desc}</p>
              </div>
            ))}
          </motion.div>
        )}

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-xs text-zinc-600 mt-8 max-w-2xl"
        >
          <p>
            <strong>নোট:</strong> সার্ভার-সাইড কোড (Python, Node.js, PHP) এবং সার্ভারে সংরক্ষিত API Keys পাওয়া সম্ভব নয়। 
            শুধুমাত্র ব্রাউজারে লোড হওয়া কোড (HTML, CSS, JavaScript) এক্সট্র্যাক্ট করা যায়।
          </p>
        </motion.div>

      </div>
    </div>
  );
}
