import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import * as cheerio from "cheerio";

interface ExtractedResource {
  type: "html" | "css" | "javascript" | "inline-css" | "inline-js";
  url?: string;
  content: string;
  filename?: string;
}

interface ExtractionResult {
  url: string;
  title: string;
  resources: ExtractedResource[];
  error?: string;
}

async function fetchWithTimeout(url: string, timeout = 10000): Promise<Response> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { 
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    throw error;
  }
}

function resolveUrl(base: string, relative: string): string {
  try {
    return new URL(relative, base).href;
  } catch {
    return relative;
  }
}

function getFilenameFromUrl(url: string): string {
  try {
    const pathname = new URL(url).pathname;
    const parts = pathname.split('/');
    return parts[parts.length - 1] || 'index';
  } catch {
    return 'unknown';
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/extract", async (req, res) => {
    try {
      const { url } = req.body;
      
      if (!url) {
        return res.status(400).json({ error: "URL is required" });
      }

      let targetUrl = url;
      if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
        targetUrl = "https://" + targetUrl;
      }

      const resources: ExtractedResource[] = [];
      
      // Fetch main HTML
      const htmlResponse = await fetchWithTimeout(targetUrl);
      if (!htmlResponse.ok) {
        return res.status(400).json({ error: `Failed to fetch website: ${htmlResponse.status}` });
      }
      
      const html = await htmlResponse.text();
      const $ = cheerio.load(html);
      
      // Get page title
      const title = $('title').text() || 'Untitled';
      
      // Add main HTML
      resources.push({
        type: "html",
        url: targetUrl,
        content: html,
        filename: "index.html"
      });

      // Extract inline styles
      $('style').each((i, el) => {
        const content = $(el).html();
        if (content && content.trim()) {
          resources.push({
            type: "inline-css",
            content: content,
            filename: `inline-style-${i + 1}.css`
          });
        }
      });

      // Extract inline scripts
      $('script:not([src])').each((i, el) => {
        const content = $(el).html();
        if (content && content.trim()) {
          resources.push({
            type: "inline-js",
            content: content,
            filename: `inline-script-${i + 1}.js`
          });
        }
      });

      // Extract external CSS links
      const cssPromises: Promise<void>[] = [];
      $('link[rel="stylesheet"]').each((i, el) => {
        const href = $(el).attr('href');
        if (href) {
          const fullUrl = resolveUrl(targetUrl, href);
          cssPromises.push(
            fetchWithTimeout(fullUrl, 5000)
              .then(res => res.text())
              .then(content => {
                resources.push({
                  type: "css",
                  url: fullUrl,
                  content: content,
                  filename: getFilenameFromUrl(fullUrl) || `style-${i + 1}.css`
                });
              })
              .catch(() => {
                resources.push({
                  type: "css",
                  url: fullUrl,
                  content: `/* Failed to fetch: ${fullUrl} */`,
                  filename: getFilenameFromUrl(fullUrl) || `style-${i + 1}.css`
                });
              })
          );
        }
      });

      // Extract external JavaScript
      const jsPromises: Promise<void>[] = [];
      $('script[src]').each((i, el) => {
        const src = $(el).attr('src');
        if (src) {
          const fullUrl = resolveUrl(targetUrl, src);
          jsPromises.push(
            fetchWithTimeout(fullUrl, 5000)
              .then(res => res.text())
              .then(content => {
                resources.push({
                  type: "javascript",
                  url: fullUrl,
                  content: content,
                  filename: getFilenameFromUrl(fullUrl) || `script-${i + 1}.js`
                });
              })
              .catch(() => {
                resources.push({
                  type: "javascript",
                  url: fullUrl,
                  content: `// Failed to fetch: ${fullUrl}`,
                  filename: getFilenameFromUrl(fullUrl) || `script-${i + 1}.js`
                });
              })
          );
        }
      });

      // Wait for all fetches
      await Promise.all([...cssPromises, ...jsPromises]);

      const result: ExtractionResult = {
        url: targetUrl,
        title,
        resources
      };

      res.json(result);
    } catch (error: any) {
      console.error("Extraction error:", error);
      res.status(500).json({ 
        error: error.message || "Failed to extract website source code" 
      });
    }
  });

  return httpServer;
}
